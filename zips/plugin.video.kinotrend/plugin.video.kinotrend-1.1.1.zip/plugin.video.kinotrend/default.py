# -*- coding: utf-8 -*-
import os
import json
import xbmc, xbmcgui, xbmcplugin
import urllib
from simpleplugin import RoutedPlugin
try:
    import urllib2
except:
    import urllib.request as urllib2
plugin = RoutedPlugin()


@plugin.route('/')
def root():
    listing = get_releases_list()
    return plugin.create_listing(listing, content='movies', sort_methods=(xbmcplugin.SORT_METHOD_DATEADDED, xbmcplugin.SORT_METHOD_VIDEO_RATING), cache_to_disk=True)


@plugin.route('/film')
def film():
    use_torrserve = plugin.get_setting('use_engine', True)
    id = int(plugin.params.id)
    major_version = int(xbmc.getInfoLabel('System.BuildVersion')[:2])

    info = []
    releases = get_json()
    for release in releases:
        if release['filmID'] == id:
            info = release['torrents']
            break
    list_torrent = []
    list = []
    auto_play = plugin.get_setting('auto_play', True)
    filter_quality = plugin.get_setting('filter_quality', True)
    for i in info:
        if(filter_quality):
            if(plugin.get_setting('filter_quality_{0}'.format(i['quality']), True)):
                list_torrent.append(i['magnet'])
            else:
                continue
        else:
            list_torrent.append(i['magnet'])
        date = i['date'].split('-')
        date = date[2]+"."+date[1]+"."+date[0]
        size = lic = ""

        if i.get('size', 0):
            size = " [[B]" + humanizeSize(i['size']) + "[/B]]"

        if i.get('audio') == "P":
            lic = " / [B]П.М.[/B] /"
        elif i.get('audio') == "D":
            lic = " / [B]Дубляж[/B] /"
        else:
            lic = " / [B]Лицензия[/B] /"

        label = i['type'].replace('UHD', '4K') + size
        if major_version > 16:
            label2 = "{0}{1} Раздают: {2} / Качают: {3}".format(date, lic, i['seeders'], i['leechers'])
            thumb = os.path.join(plugin.path, 'resources', 'images', 'rutor.png')
            if 'kinozal' in i['magnet']:
                thumb = os.path.join(plugin.path, 'resources', 'images', 'kinozal.png')
            li = plugin.create_list_item({"label": label, "label2": label2, "thumb": thumb})
            list.append(li)
        else:
            list.append(label)

    if (len(list_torrent) > 0):
        if not auto_play:
            if major_version > 16:
                dialog = xbmcgui.Dialog()
                ret = dialog.select('Список торрентов', list=list, useDetails=True)
            else:
                dialog = xbmcgui.Dialog()
                ret = dialog.select('Список торрентов', list=list)
        else:
            ret = len(list_torrent) - 1
        if ret > -1:
            t_url = list_torrent[ret]
            if use_torrserve:
                ip = plugin.get_setting('ts-host', True)
                port = plugin.get_setting('ts-port', True)
                path = "http://{0}:{1}/torrent/play?link={2}&preload=0&file=0&save=true".format(ip, port, t_url)
            else:
                path = "plugin://plugin.video.elementum/play?uri={0}".format(t_url)
            return plugin.resolve_url(path, succeeded=True)
    else:
        xbmcgui.Dialog().ok("Нет подходящих торрентов", "Нет подходящих под фильтр торрентов")
        return plugin.resolve_url(succeeded=False)


def humanizeSize(size):
    B = u"б"
    KB = u"Кб"
    MB = u"Мб"
    GB = u"Гб"
    TB = u"Тб"
    UNITS = [B, KB, MB, GB, TB]
    HUMANFMT = "%.2f %s"
    HUMANRADIX = 1024.

    for u in UNITS[:-1]:
        if size < HUMANRADIX: return HUMANFMT % (size, u)
        size /= HUMANRADIX

    return HUMANFMT % (size, UNITS[-1])


@plugin.cached(60)
def get_json():
    page = urllib2.urlopen('https://kino-trend.000webhostapp.com/movies.json').read()
    releases = json.loads(page.decode('utf-8'))
    releases = releases['movies']
    return releases


def get_releases_list():
    releases = get_json()
    major_version = int(xbmc.getInfoLabel('System.BuildVersion')[:2])
    listing = []
    num = 0
    for release in releases:
        timestr = release['filmLength']
        ftr = [3600,60]
        duration = sum([a*b for a,b in zip(ftr, map(int,timestr.split(':')))])
        s=num
        hour = s / 3600
        min = (s - hour * 3600) / 60
        sec = s - hour * 3600 - min * 60
        fake_time = '%02d:%02d:%02d' % (hour, min, 59 - sec)
        cm = []
        playcount = get_playcount(release['filmID'])
        if (playcount > 0):
            cm.append(('Не просмотренно', 'RunPlugin(%s)' % plugin.url_for('mark_unwatched', id=release['filmID'])))
        else:
            cm.append(('Просмотренно', 'RunPlugin(%s)' % plugin.url_for('mark_watched', id=release['filmID'])))
        if major_version < 17:
            cm.append(('Сведения', 'Action(Info)'))
        if release['trailerYoutube'] != "":
            cm.append((
                'Трейлер', 
                'RunPlugin("plugin://plugin.video.youtube/play/?video_id={0}")'.format(release['trailerYoutube'].replace("https://www.youtube.com/watch?v=", "")),
            ))

        listing.append({
            'label': release['nameRU'],
            'art': {
                'thumb': release['bigPosterURL'],
                'poster': release['posterURL'],
                'fanart': release['bigPosterURL'],
                'icon': release['posterURL']
            },
            'info': {
                'video': {
                    'imdbnumber': release['imdbID'],
                    'count': num,
                    'cast': release['actors'].split(','),
                    'dateadded': release['torrentsDate'] + " "+fake_time,
                    'director': release['directors'].split(','),
                    'genre': release['genre'].split(','),
                    'country': release['country'],
                    'year': int(release['year']),
                    'rating': float(release['ratingFloat']),
                    'plot': release['description'],
                    'plotoutline': release['description'],
                    'title': release['nameRU'],
                    'sorttitle': release['nameRU'],
                    'duration': duration,
                    'originaltitle': release['nameOriginal'],
                    'premiered': release['premierDate'],
                    'votes': int(release['ratingKPCount']),
                    'trailer': release['trailerYoutube'].replace("https://www.youtube.com/watch?v=", "plugin://plugin.video.youtube/play/?video_id="),
                    'mediatype': 'movie',
                    'tagline': release['slogan'],
                    'mpaa': release['ratingMPAA'] if release['ratingAgeLimits'] == "" else release['ratingAgeLimits'],
                    'playcount': playcount,
                }
            },
            'is_folder': False,
            'is_playable': True,
            'url': plugin.url_for('film', id=release['filmID']),
            'context_menu': cm,
            'online_db_ids': ({'imdb': release['imdbID'], 'tmdb' : release['imdbID']}, "imdb")
            })
        num += 1
    return listing

@plugin.route('/mark_watched')
def mark_watched():
    id = plugin.params.id
    with plugin.get_storage("watched") as storage:
        storage[id] = 1
    return xbmc.executebuiltin("Container.Refresh")


@plugin.route('/mark_unwatched')
def mark_unwatched():
    id = plugin.params.id
    with plugin.get_storage("watched") as storage:
        storage[id] = 0
    return xbmc.executebuiltin("Container.Refresh")

def get_playcount(id):
    count = 0
    with plugin.get_storage("watched") as storage:
        count = storage.get(str(id), 0) 
    return count

if __name__ == '__main__':
    plugin.run()